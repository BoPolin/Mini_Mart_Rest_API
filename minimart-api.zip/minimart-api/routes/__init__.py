from routes.user import *
from routes.category import *
from routes.customer import *
from routes.invoice_detail import *
from routes.product import *
from routes.invoice import *
from routes.report import *
from routes.auth import *